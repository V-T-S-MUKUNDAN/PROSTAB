# some code adated from https://github.com/BytedProtein/ByProt and https://github.com/ashleve/lightning-hydra-template
import spurs.models
import spurs.tasks
import spurs.utils
import spurs.datamodules